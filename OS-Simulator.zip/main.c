/*#include <stdio.h>
#include <string.h>

int main(){

    char name[] = "Bro Code";
    char food[] = "Osh";

    printf("Your food is %s\n", food);

    printf("Hello %s\n", name);

    return 0;
}

int main(){
    FILE *file = fopen("C:/Users/NITRO/Desktop/softwarelist.txt", "r");
    char line[256];
    char *search_term = "Adobe";

    if(file == NULL){
        perror("Error opening file");
        return 1;
    }
int line_number = 0;
    int count = 0;
    while(fgets(line,sizeof(line),file)){
        line_number++;

        if(strstr(line, search_term)) {
            printf("%d: %s",line_number, line);
            count++;
        }
    }
    printf("\nThe word '%s' appeared %d times.\n", search_term, count);

    fclose(file);
    return 0;
}
 */
#include <stdio.h>
#include <string.h>

int main(){

    FILE *in = fopen("C:/Users/NITRO/Desktop/Input.txt", "r");
    FILE *out = fopen("C:/Users/NITRO/Desktop/Output.txt", "w");
    char line[256];
    int word_count = 0;

    if(in == NULL || out == NULL){
        perror("Error opening file");
        return 1;
    }
    int line_number = 0;
    int count = 0;
    while(fgets(line,sizeof(line), in)){
        fputs(line,out);

        int in_word = 0;
        for (int i = 0; line[i] != '\0'; i++) {
            if (line[i] != ' ' && line[i] != '\n' && line[i] != '\r' && line[i] != '\t') {
                if (!in_word) {
                    word_count++;
                    in_word = 1;
                }
            }else{
            in_word = 0;
            }
        }
    }
    printf("File created successfully.\n");
    printf("Total words %d\n", word_count);

    fclose(in);
    fclose(out);


    return 0;
}