#include <stdio.h>

struct Process {
    int id;
    int arrival;
    int burst;
    int priority;
    int waiting;
    int turnaround;
};

int main() {
    int n = 5;
    struct Process p[100];
    int i;

    printf("Enter details for %d processes:\n", n);

    for(i = 0; i < n; i++) {
        p[i].arrival = i;  // simple arrival times: 0,1,2,3,4

        printf("\nProcess %d ID: ", i+1);
        scanf("%d", &p[i].id);

        printf("Burst time for Process %d: ", i+1);
        scanf("%d", &p[i].burst);

        printf("Priority for Process %d: ", i+1);
        scanf("%d", &p[i].priority);

        p[i].waiting = 0;
        p[i].turnaround = 0;
    }

    // --------- FCFS SCHEDULING ----------
    int total_waiting = 0, total_turnaround = 0;
    int current_time = 0;

    for(i = 0; i < n; i++) {
        if(current_time < p[i].arrival)
            current_time = p[i].arrival;  // wait cpu is idle

        p[i].waiting = current_time - p[i].arrival;   // waiting time
        p[i].turnaround = p[i].waiting + p[i].burst;  // turnaround time

        current_time += p[i].burst;  // move cpu time forward

        total_waiting += p[i].waiting;
        total_turnaround += p[i].turnaround;
    }

    // --------- OUTPUT ----------
    printf("\nFCFS Scheduling Results:\n");
    printf("ID\tArrival\tBurst\tWaiting\tTurnaround\n");
    for(i = 0; i < n; i++) {
        printf("%d\t%d\t%d\t%d\t%d\n",
               p[i].id, p[i].arrival, p[i].burst, p[i].waiting, p[i].turnaround);
    }

    printf("\nAverage waiting time: %.2f\n", (float)total_waiting/n);
    printf("Average turnaround time: %.2f\n", (float)total_turnaround/n);

    return 0;
}
